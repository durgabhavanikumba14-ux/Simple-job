# Architecture

## 1. High-level system architecture

```
 Browser / Mobile Web (React)
        |  HTTPS
        v
  CDN + WAF  --->  API Gateway / Load Balancer
                        |
        +---------------+-------------------------+
        v               v                         v
   API Service     Matching Service        Recruiter/Search Service
   (FastAPI)       (read APIs, cached)     (filters, FTS, vector)
        |               |                         |
        +------+--------+-------------------------+
               |                      |
          Redis (cache,         PostgreSQL 16 + pgvector
          rate limits,          (primary + read replicas,
          Celery broker)         PgBouncer pooling)
               |
        Celery workers  <-- queues: parse, score
        - parse_resume   (extract text, tag skills, embed)
        - score_resume_vs_jobs / score_job_vs_resumes
               |
        Object Storage (S3 / GCS) -- private bucket, SSE-KMS, signed URLs
               ^
               +-- Browser uploads/downloads directly via presigned URLs
```

### Data flow: resume upload -> parsed skills -> match score
1. `POST /resumes/upload-url` -> API validates type/size, creates a `resumes` row (`status=pending`), returns a **presigned PUT URL** (5 min, content-type locked).
2. Browser uploads the file **directly to S3** (API never proxies bytes).
3. `POST /resumes/{id}/complete` -> API verifies the object exists (HEAD), enqueues `parse_resume` on the `parse` queue, returns `202`.
4. Worker: download -> extract text (pdfminer / python-docx) -> taxonomy phrase match, then embedding fallback to canonical skills -> write `resume_skills` + resume embedding -> `status=parsed` -> enqueue `score_resume_vs_jobs`.
5. Scoring worker: pgvector ANN prefilter of top-N candidate jobs, then exact weighted score -> upsert `match_scores` (matched/missing JSON) -> invalidate Redis keys.
6. `GET /matches` reads `match_scores` (cache-aside in Redis). UI shows progress circle + red gaps + course links.
7. New/edited job: `score_job_vs_resumes` runs in batches (only for resumes passing a skill-overlap prefilter), so 10K jobs x 100K resumes (1B pairs) is **never computed in full**.

### Why not compute all pairs?
Score lazily and incrementally: (a) top-K ANN prefilter per resume (K~200), (b) recompute only when a resume's skills or a job's skills change, (c) cache per-user ranked lists for 10 min.

## 2. Recommended tech stack
| Layer | Choice | Why |
|---|---|---|
| Frontend | React 18 + Vite, plain responsive CSS (TanStack Query optional) | Fast, mobile-first |
| API | Python FastAPI (async) + Pydantic | Same language as the NLP/parsing stack |
| Workers | Celery + Redis broker (BullMQ is the Node equivalent) | Retries, queue routing, rate control |
| DB | PostgreSQL 16 + pgvector (HNSW) + pg_trgm + FTS | One store for relational, vector and text search at this scale |
| Cache / limits | Redis 7 | Atomic Lua counters, cache-aside, broker |
| Storage | S3 (or GCS) private bucket, SSE-KMS, presigned URLs | Secure direct uploads |
| NLP | pdfminer.six, python-docx, sentence-transformers (all-MiniLM-L6-v2, 384-d) | Cheap, self-hosted embeddings |
| Infra | Docker, Kubernetes/ECS, PgBouncer, Prometheus | Horizontal scale |

Why Postgres+pgvector over Elasticsearch: 100K resumes + 10K jobs is small for pgvector HNSW (low-ms ANN). Keep Elasticsearch/OpenSearch as an upgrade path if recruiter free-text relevance tuning outgrows Postgres FTS.

## 3. Scalability notes
- **Sizing**: ~100K resumes x ~30 skills = ~3M `resume_skills` rows; 10K jobs x ~12 = ~120K `job_skills` rows. Fits easily on a mid-size instance.
- **Read replicas** for recruiter search and match reads; primary for writes.
- **PgBouncer** (transaction mode) plus an async pool in the API.
- **Worker autoscaling** on queue depth. Separate `parse` (CPU/IO) and `score` (DB) queues. Use `acks_late`, retries with backoff, and idempotent tasks.
- **Embeddings**: the skill taxonomy (~10-30K canonical skills) is embedded once. Resume vector = mean of its skill vectors. No per-request model calls.
- **Backpressure**: upload endpoints return `202`; clients poll `GET /resumes/{id}` (or SSE/WebSocket).

## 4. Caching strategy (Redis)
| Key | Value | TTL | Invalidation |
|---|---|---|---|
| `matches:{user_id}:{resume_id}` | ranked job list | 10 min | on `score_*` completion |
| `gap:{resume_id}:{job_id}` | matched/missing + courses | 1 h | resume or job skills change |
| `job:{id}` | job detail | 15 min | job update |
| `skill_courses:{skill_id}` | course list | 24 h | admin update |
| `rl:apply:{user_id}:{YYYYMMDD}` | counter | until next UTC midnight | none |

Cache-aside with jittered TTL to avoid stampedes; single-flight lock (`SET NX`) on cold recompute.

## 5. Secure storage design
- Private bucket, **Block Public Access**, SSE-KMS, versioning, lifecycle rule deleting orphaned `pending` uploads after 24 h.
- Object key: `resumes/{user_id}/{resume_id}/{uuid}.{ext}`, never derived from the user's filename.
- Upload: presigned **PUT**, content-type allow-list (PDF/DOCX), size capped (5 MB; enforce with a POST policy `content-length-range` or a post-upload HEAD check), 5 min expiry.
- Download: presigned **GET**, 60 s expiry, only after authorization (owner, or a recruiter for a candidate who applied to their job). Force `attachment` disposition.
- CORS restricted to the app origin. Malware scan (ClamAV / cloud scanning) and magic-byte validation before parsing.
- PII: audit log on recruiter downloads; GDPR delete job removes S3 object + rows + embeddings.

## 6. Application rate limit (10 jobs/day)
Two layers (see `backend/app/rate_limit.py`):
1. **Redis Lua script**: atomic check-and-increment of `rl:apply:{user}:{UTC date}`; rejects with `429` + `Retry-After` on the 11th attempt. TTL = seconds to next UTC midnight.
2. **Postgres is the source of truth**: `applications` insert in a transaction with a unique `(user_id, job_id)` constraint. If the insert fails (duplicate, job closed), the Redis slot is **released**. If Redis is down, fall back to counting today's rows under a per-user advisory lock.

The day boundary is UTC; switch to per-user timezone if the business wants local "days".

## 7. Match score formula
```
score = 100 * sum_j( w_j * s_j ) / sum_j( w_j )
w_j = 2.0 for required skills, 1.0 for nice-to-have (times job-specific importance)
s_j = best similarity between job skill j and any candidate skill
      1.0 for an exact canonical match;
      semantic match counts only if cos_sim >= 0.80 (else 0, i.e. MISSING)
```
Missing = job skills with `s_j < 0.80`. Each missing skill maps to courses through `skill_courses`.

## 8. Security & observability checklist
JWT access + refresh tokens, RBAC (applicant / recruiter / admin), gateway per-IP rate limiting, structured logs with request IDs, queue-depth and parse-latency dashboards, Sentry, secrets in a secret manager.
