# Wireframes

## Applicant dashboard (desktop >= 900px)
```
+--------------------------------------------------------------------------+
| Logo      Dashboard  Jobs  Resume                        [avatar v]      |
+--------------------------------------------------------------------------+
| My Resume: jane_doe.pdf (parsed)   [Replace]   Skills: Python React ...  |
| Applications today: 3 / 10                                               |
+--------------------------------------------------------------------------+
| Top matches                                   | Selected job             |
| +--------------------------------------+      |  Senior Backend Eng      |
| | (82%) Backend Engineer - Acme   [>]  |      |       ( 82% )            |
| | (71%) Data Engineer - Globex    [>]  |      |  Matched: Python SQL ... |
| | (64%) ML Engineer - Initech     [>]  |      |  Missing (red):          |
| +--------------------------------------+      |   [Kubernetes] -> Course |
|                                               |   [Kafka]      -> Course |
|                                               |  [ Apply (3/10 today) ]  |
+--------------------------------------------------------------------------+
```

## Applicant dashboard (mobile < 600px)
```
+--------------------+
| = Logo        (o)  |
+--------------------+
| Applied today 3/10 |
| +----------------+ |
| |  (82%) Backend | |
| |  Acme          | |
| |  Missing:      | |
| |  [Kubernetes]  | |
| |  [Kafka]       | |
| |  Learn: ...    | |
| |  [Apply]       | |
| +----------------+ |
| (71%) Data Eng  >  |
| (64%) ML Eng    >  |
+--------------------+
```

## Recruiter directory
```
+--------------------------------------------------------------------------+
| Search: [ python kubernetes______ ]  Skills[v]  Min exp[v]  Location[v]  |
|  [x] Python  [x] AWS          Rank by job: [ Job v ]  Min match [ 60% ]  |
+--------------------------------------------------------------------------+
| Candidate   | Top skills            | Exp | Location | Match              |
| J. Doe      | Python, AWS, SQL      | 5y  | Chennai  | (82%)              |
| A. Kumar    | Python, Docker, K8s   | 7y  | Remote   | (77%)              |
+--------------------------------------------------------------------------+
| < 1 2 3 ... >        (mobile: cards, filters in a bottom sheet)          |
+--------------------------------------------------------------------------+
```
