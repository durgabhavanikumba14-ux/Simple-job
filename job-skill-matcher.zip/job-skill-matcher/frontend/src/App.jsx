import React, { useState } from "react";
import ApplicantDashboard from "./components/ApplicantDashboard.jsx";
import RecruiterDirectory from "./components/RecruiterDirectory.jsx";

export default function App() {
  const [view, setView] = useState("applicant");
  return (
    <>
      <header className="topbar">
        <strong>SkillMatch</strong>
        <nav>
          <button className={view === "applicant" ? "active" : ""} onClick={() => setView("applicant")}>Applicant</button>
          <button className={view === "recruiter" ? "active" : ""} onClick={() => setView("recruiter")}>Recruiter</button>
        </nav>
      </header>
      <main className="container">
        {view === "applicant" ? <ApplicantDashboard /> : <RecruiterDirectory />}
      </main>
    </>
  );
}
