import React from "react";

/**
 * data = { matched: [{skill_id, name}], missing: [{skill_id, name, required, courses:[{title, provider, url, duration_hours, is_free}]}] }
 * Missing skills are rendered in red, with actionable training links.
 */
export default function SkillGapView({ data }) {
  if (!data) return null;
  const { matched = [], missing = [] } = data;
  const required = missing.filter((m) => m.required);
  const nice = missing.filter((m) => !m.required);

  return (
    <section className="gap">
      <h3>Skills you have <span className="count">{matched.length}</span></h3>
      <div className="chips">
        {matched.map((s) => <span key={s.skill_id} className="chip chip--ok">{s.name}</span>)}
        {!matched.length && <em>No overlapping skills yet.</em>}
      </div>

      <h3 className="red">Missing skills <span className="count count--red">{missing.length}</span></h3>
      {!missing.length && <p className="ok-text">You cover every skill for this role. 🎉</p>}

      {[["Required", required], ["Nice to have", nice]].map(([title, list]) =>
        list.length ? (
          <div key={title}>
            <h4>{title}</h4>
            <ul className="gap-list">
              {list.map((s) => (
                <li key={s.skill_id} className="gap-item">
                  <span className="chip chip--missing">{s.name}</span>
                  <div className="courses">
                    {s.courses?.length ? s.courses.map((c) => (
                      <a key={c.url} href={c.url} target="_blank" rel="noopener noreferrer">
                        {c.title} <small>· {c.provider}{c.is_free ? " · Free" : ""}{c.duration_hours ? ` · ${c.duration_hours}h` : ""}</small>
                      </a>
                    )) : <small className="muted">No course linked yet</small>}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        ) : null
      )}
    </section>
  );
}
