import React, { useRef, useState } from "react";
import { api } from "../api.js";

const OK = ["application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];

export default function ResumeUpload({ onParsed }) {
  const input = useRef();
  const [state, setState] = useState("idle"); // idle | uploading | parsing | done | error

  const onFile = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!OK.includes(file.type) || file.size > 5 * 1024 * 1024) { setState("error"); return; }
    try {
      setState("uploading");
      const id = await api.uploadResume(file);
      setState("parsing");
      for (let i = 0; i < 30; i++) {                    // poll until worker finishes
        await new Promise((r) => setTimeout(r, 2000));
        const r = await api.resume(id);
        if (r.status === "parsed") { setState("done"); setTimeout(onParsed, 3000); return; }
        if (r.status === "failed") throw new Error("parse failed");
      }
    } catch { setState("error"); }
  };

  const text = { idle: "Upload resume (PDF/DOCX, ≤5 MB)", uploading: "Uploading…", parsing: "Parsing skills…",
                 done: "Parsed ✓ — computing matches", error: "Upload failed — retry" }[state];
  return (
    <>
      <input ref={input} type="file" hidden accept=".pdf,.docx" onChange={onFile} />
      <button onClick={() => input.current.click()} disabled={state === "uploading" || state === "parsing"}>{text}</button>
    </>
  );
}
