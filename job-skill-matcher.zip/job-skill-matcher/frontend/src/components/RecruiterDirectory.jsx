import React, { useEffect, useState } from "react";
import { api } from "../api.js";
import MatchScoreCircle from "./MatchScoreCircle.jsx";

export default function RecruiterDirectory() {
  const [filters, setFilters] = useState({ q: "", location: "", min_exp: "", job_id: "", min_score: "" });
  const [page, setPage] = useState(1);
  const [data, setData] = useState({ items: [], total: 0 });
  const [showFilters, setShowFilters] = useState(false);   // mobile bottom sheet

  // Debounce typing so we don't hammer the API
  useEffect(() => {
    const t = setTimeout(() => {
      const p = new URLSearchParams({ page });
      Object.entries(filters).forEach(([k, v]) => v && p.set(k, v));
      api.candidates(p).then(setData).catch(() => {});
    }, 300);
    return () => clearTimeout(t);
  }, [filters, page]);

  const set = (k) => (e) => { setPage(1); setFilters({ ...filters, [k]: e.target.value }); };

  return (
    <div>
      <div className="card filters-bar">
        <input placeholder="Search resumes (e.g. python kubernetes)" value={filters.q} onChange={set("q")} />
        <button className="only-mobile" onClick={() => setShowFilters(!showFilters)}>Filters</button>
        <div className={`filters ${showFilters ? "open" : ""}`}>
          <input placeholder="Location" value={filters.location} onChange={set("location")} />
          <input type="number" min="0" placeholder="Min years exp" value={filters.min_exp} onChange={set("min_exp")} />
          <input placeholder="Job ID (rank by match)" value={filters.job_id} onChange={set("job_id")} />
          <input type="number" min="0" max="100" placeholder="Min match %" value={filters.min_score} onChange={set("min_score")} />
        </div>
      </div>

      <p className="muted">{data.total} candidates</p>
      <div className="candidate-grid">
        {data.items.map((c) => (
          <article key={c.resume_id} className="card candidate">
            <div>
              <strong>{c.full_name}</strong>
              <div className="muted">{c.location || "—"} · {c.years_experience ?? "?"} yrs</div>
              <div className="chips">{(c.top_skills || []).map((s) => <span key={s} className="chip">{s}</span>)}</div>
            </div>
            {c.score != null && <MatchScoreCircle score={c.score} size={56} stroke={6} label="" />}
          </article>
        ))}
      </div>

      <div className="pager">
        <button disabled={page === 1} onClick={() => setPage(page - 1)}>‹ Prev</button>
        <span>Page {page}</span>
        <button disabled={page * 20 >= data.total} onClick={() => setPage(page + 1)}>Next ›</button>
      </div>
    </div>
  );
}
