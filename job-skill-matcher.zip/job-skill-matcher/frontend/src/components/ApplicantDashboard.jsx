import React, { useEffect, useState } from "react";
import { api } from "../api.js";
import MatchScoreCircle from "./MatchScoreCircle.jsx";
import SkillGapView from "./SkillGapView.jsx";
import ResumeUpload from "./ResumeUpload.jsx";

export default function ApplicantDashboard() {
  const [matches, setMatches] = useState([]);
  const [selected, setSelected] = useState(null);
  const [gap, setGap] = useState(null);
  const [quota, setQuota] = useState({ used: 0, limit: 10, remaining: 10 });
  const [msg, setMsg] = useState("");

  const load = () => { api.matches().then(setMatches).catch(() => {}); api.quota().then(setQuota).catch(() => {}); };
  useEffect(load, []);
  useEffect(() => { if (selected) api.gap(selected.job_id).then(setGap).catch(() => setGap(null)); }, [selected]);

  const apply = async () => {
    try {
      const r = await api.apply(selected.job_id);
      setMsg(`Applied! ${r.remaining_today} applications left today.`);
      load();
    } catch (e) {
      setMsg(e.status === 429 ? "Daily limit reached (10/day). Try again tomorrow." : e.message);
    }
  };

  return (
    <div className="dashboard">
      <div className="card toolbar">
        <ResumeUpload onParsed={load} />
        <div className="quota">Applications today: <strong>{quota.used} / {quota.limit}</strong></div>
      </div>

      <div className="split">
        <ul className="match-list">
          {matches.map((m) => (
            <li key={m.job_id} className={`card match ${selected?.job_id === m.job_id ? "selected" : ""}`}
                onClick={() => setSelected(m)}>
              <MatchScoreCircle score={m.score} size={64} stroke={7} label="" />
              <div>
                <strong>{m.title}</strong>
                <div className="muted">{m.company} · {m.location || "Remote"}</div>
                {m.missing_count > 0 && <small className="red">{m.missing_count} missing skills</small>}
              </div>
            </li>
          ))}
          {!matches.length && <li className="card muted">No matches yet — upload your resume.</li>}
        </ul>

        {selected && (
          <aside className="card detail">
            <h2>{selected.title}</h2>
            <p className="muted">{selected.company}</p>
            <div className="center"><MatchScoreCircle score={selected.score} size={140} stroke={14} /></div>
            <SkillGapView data={gap} />
            <button className="primary" disabled={quota.remaining <= 0} onClick={apply}>
              {quota.remaining <= 0 ? "Daily limit reached" : `Apply (${quota.used}/${quota.limit} today)`}
            </button>
            {msg && <p role="status">{msg}</p>}
          </aside>
        )}
      </div>
    </div>
  );
}
