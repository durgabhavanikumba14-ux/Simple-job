import React from "react";

/**
 * Circular progress ring for a 0-100 match score.
 * Pure SVG, no dependencies. Color: red < 50, amber < 75, green >= 75.
 * Accessible: role="img" + aria-label; animates via CSS transition.
 */
export default function MatchScoreCircle({ score = 0, size = 96, stroke = 10, label = "match" }) {
  const value = Math.max(0, Math.min(100, Number(score) || 0));
  const r = (size - stroke) / 2;
  const circumference = 2 * Math.PI * r;
  const offset = circumference * (1 - value / 100);
  const color = value >= 75 ? "var(--green)" : value >= 50 ? "var(--amber)" : "var(--red)";

  return (
    <div className="score-circle" style={{ width: size, height: size }}
         role="img" aria-label={`${Math.round(value)} percent ${label}`}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--track)" strokeWidth={stroke} />
        <circle
          cx={size / 2} cy={size / 2} r={r} fill="none"
          stroke={color} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={circumference} strokeDashoffset={offset}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
          style={{ transition: "stroke-dashoffset .8s ease, stroke .3s" }}
        />
      </svg>
      <div className="score-circle__text">
        <span className="score-circle__value">{Math.round(value)}%</span>
        <span className="score-circle__label">{label}</span>
      </div>
    </div>
  );
}
