const token = () => localStorage.getItem("token");

async function req(path, opts = {}) {
  const res = await fetch(`/api${path}`, {
    ...opts,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token()}`, ...(opts.headers || {}) },
  });
  if (!res.ok) {
    const err = new Error((await res.json().catch(() => ({}))).detail || res.statusText);
    err.status = res.status;
    throw err;
  }
  return res.json();
}

export const api = {
  matches: () => req("/matches"),
  gap: (jobId) => req(`/matches/${jobId}/gap`),
  quota: () => req("/applications/quota"),
  apply: (jobId) => req(`/applications/${jobId}`, { method: "POST" }),
  candidates: (params) => req(`/recruiter/candidates?${params}`),

  // Resume upload: presigned POST direct to S3, then notify API
  async uploadResume(file) {
    const { resume_id, upload } = await req("/resumes/upload-url", {
      method: "POST",
      body: JSON.stringify({ filename: file.name, mime_type: file.type, size: file.size }),
    });
    const form = new FormData();
    Object.entries(upload.fields).forEach(([k, v]) => form.append(k, v));
    form.append("file", file);                      // file must be last
    const s3 = await fetch(upload.url, { method: "POST", body: form });
    if (!s3.ok) throw new Error("Upload failed");
    await req(`/resumes/${resume_id}/complete`, { method: "POST" });
    return resume_id;
  },
  resume: (id) => req(`/resumes/${id}`),
};
