-- PostgreSQL 16 + pgvector
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

CREATE TYPE user_role AS ENUM ('applicant', 'recruiter', 'admin');
CREATE TYPE resume_status AS ENUM ('pending', 'uploaded', 'parsing', 'parsed', 'failed');
CREATE TYPE application_status AS ENUM ('submitted', 'viewed', 'shortlisted', 'rejected', 'withdrawn');

CREATE TABLE users (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email         CITEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role          user_role NOT NULL DEFAULT 'applicant',
  full_name     TEXT NOT NULL,
  location      TEXT,
  years_experience NUMERIC(4,1),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Canonical skill taxonomy (~10-30K rows) with one embedding per skill
CREATE TABLE skills (
  id         SERIAL PRIMARY KEY,
  name       TEXT NOT NULL UNIQUE,           -- canonical, e.g. 'kubernetes'
  aliases    TEXT[] NOT NULL DEFAULT '{}',   -- 'k8s', 'kube'
  category   TEXT,
  embedding  vector(384) NOT NULL
);
CREATE INDEX skills_embedding_hnsw ON skills USING hnsw (embedding vector_cosine_ops);
CREATE INDEX skills_aliases_gin    ON skills USING gin (aliases);
CREATE INDEX skills_name_trgm      ON skills USING gin (name gin_trgm_ops);

CREATE TABLE resumes (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  storage_key  TEXT NOT NULL,                -- S3/GCS object key
  original_name TEXT,
  mime_type    TEXT NOT NULL,
  status       resume_status NOT NULL DEFAULT 'pending',
  raw_text     TEXT,
  search_tsv   TSVECTOR,
  embedding    vector(384),                  -- mean of skill vectors
  is_active    BOOLEAN NOT NULL DEFAULT true,
  parsed_at    TIMESTAMPTZ,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX resumes_user_idx      ON resumes (user_id);
CREATE UNIQUE INDEX resumes_one_active_per_user ON resumes (user_id) WHERE is_active;
CREATE INDEX resumes_tsv_gin       ON resumes USING gin (search_tsv);
CREATE INDEX resumes_emb_hnsw      ON resumes USING hnsw (embedding vector_cosine_ops) WHERE is_active AND status = 'parsed';

CREATE TABLE resume_skills (
  resume_id  UUID NOT NULL REFERENCES resumes(id) ON DELETE CASCADE,
  skill_id   INT  NOT NULL REFERENCES skills(id),
  confidence REAL NOT NULL DEFAULT 1.0,
  PRIMARY KEY (resume_id, skill_id)
);
CREATE INDEX resume_skills_skill_idx ON resume_skills (skill_id, resume_id);  -- recruiter "has skill X" filters

CREATE TABLE jobs (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recruiter_id UUID NOT NULL REFERENCES users(id),
  title       TEXT NOT NULL,
  company     TEXT NOT NULL,
  description TEXT NOT NULL,
  location    TEXT,
  remote      BOOLEAN DEFAULT false,
  min_years_experience NUMERIC(4,1),
  status      TEXT NOT NULL DEFAULT 'open',
  search_tsv  TSVECTOR,
  embedding   vector(384),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX jobs_open_idx  ON jobs (created_at DESC) WHERE status = 'open';
CREATE INDEX jobs_tsv_gin   ON jobs USING gin (search_tsv);
CREATE INDEX jobs_emb_hnsw  ON jobs USING hnsw (embedding vector_cosine_ops) WHERE status = 'open';

CREATE TABLE job_skills (
  job_id     UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  skill_id   INT  NOT NULL REFERENCES skills(id),
  required   BOOLEAN NOT NULL DEFAULT true,
  weight     REAL NOT NULL DEFAULT 1.0,
  PRIMARY KEY (job_id, skill_id)
);
CREATE INDEX job_skills_skill_idx ON job_skills (skill_id, job_id);

-- Precomputed scores (resume x job); only top-K per resume are stored
CREATE TABLE match_scores (
  resume_id  UUID NOT NULL REFERENCES resumes(id) ON DELETE CASCADE,
  job_id     UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  score      NUMERIC(5,2) NOT NULL,          -- 0..100
  matched    JSONB NOT NULL DEFAULT '[]',    -- [{skill_id,name,sim}]
  missing    JSONB NOT NULL DEFAULT '[]',    -- [{skill_id,name,required}]
  computed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (resume_id, job_id)
);
CREATE INDEX match_scores_resume_rank ON match_scores (resume_id, score DESC);
CREATE INDEX match_scores_job_rank    ON match_scores (job_id, score DESC);  -- recruiter ranking

CREATE TABLE applications (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID NOT NULL REFERENCES users(id),
  job_id     UUID NOT NULL REFERENCES jobs(id),
  resume_id  UUID NOT NULL REFERENCES resumes(id),
  status     application_status NOT NULL DEFAULT 'submitted',
  score_at_apply NUMERIC(5,2),
  applied_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, job_id)
);
CREATE INDEX applications_user_day ON applications (user_id, applied_at DESC);  -- daily limit fallback
CREATE INDEX applications_job_idx  ON applications (job_id, applied_at DESC);

CREATE TABLE courses (
  id        SERIAL PRIMARY KEY,
  title     TEXT NOT NULL,
  provider  TEXT NOT NULL,                   -- Coursera, Udemy, ...
  url       TEXT NOT NULL,
  level     TEXT,
  duration_hours REAL,
  is_free   BOOLEAN DEFAULT false
);
CREATE TABLE skill_courses (
  skill_id  INT NOT NULL REFERENCES skills(id),
  course_id INT NOT NULL REFERENCES courses(id),
  rank      SMALLINT NOT NULL DEFAULT 1,
  PRIMARY KEY (skill_id, course_id)
);

-- ---------------------------------------------------------------
-- Core matching query: score ONE resume against candidate jobs.
-- Step 1: ANN prefilter by resume embedding. Step 2: exact weighted score.
-- $1 = resume_id, $2 = similarity threshold (0.80), $3 = K (200)
-- ---------------------------------------------------------------
-- WITH cand AS (
--   SELECT j.id FROM jobs j, (SELECT embedding FROM resumes WHERE id = $1) r
--   WHERE j.status = 'open'
--   ORDER BY j.embedding <=> r.embedding LIMIT $3
-- ), per_skill AS (
--   SELECT js.job_id, js.skill_id, js.required,
--          (CASE WHEN js.required THEN 2.0 ELSE 1.0 END) * js.weight AS w,
--          COALESCE(best.sim, 0) AS sim
--   FROM job_skills js
--   JOIN cand c ON c.id = js.job_id
--   JOIN skills s ON s.id = js.skill_id
--   LEFT JOIN LATERAL (
--     SELECT MAX(CASE WHEN rs.skill_id = js.skill_id THEN 1.0
--                     ELSE 1 - (s.embedding <=> s2.embedding) END) AS sim
--     FROM resume_skills rs JOIN skills s2 ON s2.id = rs.skill_id
--     WHERE rs.resume_id = $1
--   ) best ON true
-- )
-- SELECT job_id,
--        ROUND(100 * SUM(w * CASE WHEN sim >= $2 THEN sim ELSE 0 END) / SUM(w), 2) AS score
-- FROM per_skill GROUP BY job_id ORDER BY score DESC;
