# Job Skill Matcher Platform

Closes the gap between applicant skills and job descriptions.
Designed for **100K resumes / 10K job posts** with async parsing and cached scoring.

## Contents
| Path | What |
|---|---|
| `docs/ARCHITECTURE.md` | System architecture, data flow, tech stack, scaling, caching, storage security |
| `docs/WIREFRAMES.md` | Desktop + mobile wireframes |
| `db/schema.sql` | PostgreSQL + pgvector schema, indexes, matching query |
| `backend/` | FastAPI + Celery reference implementation (upload, parsing, matching, rate limiting) |
| `frontend/` | React (Vite) components: MatchScoreCircle, SkillGapView, ApplicantDashboard, RecruiterDirectory |
| `docker-compose.yml` | Local stack: Postgres/pgvector, Redis, MinIO (S3), API, worker |

## Quick start
```bash
docker compose up -d db redis minio
psql postgresql://matcher:matcher@localhost:5432/matcher -f db/schema.sql
cd backend && pip install -r requirements.txt
uvicorn app.main:app --reload            # API  :8000
celery -A app.tasks worker -l info -Q parse,score   # worker
cd ../frontend && npm install && npm run dev        # UI   :5173
```
> Auth (`get_current_user`) is a JWT stub, and the skill taxonomy seed is minimal. Both need real data before production.
