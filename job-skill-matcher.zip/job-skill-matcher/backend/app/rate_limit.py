"""
Application rate limit: max N applications per user per UTC day.

Layer 1: atomic Redis Lua (fast path, race-free under concurrency).
Layer 2: Postgres count under advisory lock if Redis is unavailable.
The slot is RELEASED if the DB insert fails, so failures never burn quota.
"""
from datetime import datetime, timezone, timedelta
from fastapi import HTTPException
from . import db
from .config import settings

# KEYS[1]=counter key  ARGV[1]=limit  ARGV[2]=ttl seconds
# Returns {allowed(1/0), current_count}
LUA_ACQUIRE = """
local c = tonumber(redis.call('GET', KEYS[1]) or '0')
if c >= tonumber(ARGV[1]) then
  return {0, c}
end
c = redis.call('INCR', KEYS[1])
if c == 1 then redis.call('EXPIRE', KEYS[1], ARGV[2]) end
return {1, c}
"""

LUA_RELEASE = """
local c = tonumber(redis.call('GET', KEYS[1]) or '0')
if c > 0 then return redis.call('DECR', KEYS[1]) end
return 0
"""


def _today_key(user_id: str) -> tuple[str, int]:
    now = datetime.now(timezone.utc)
    midnight = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    return f"rl:apply:{user_id}:{now:%Y%m%d}", int((midnight - now).total_seconds()) + 60


async def acquire_application_slot(user_id: str) -> int:
    """Reserve one slot. Returns the new count or raises 429."""
    key, ttl = _today_key(user_id)
    limit = settings.daily_application_limit
    try:
        allowed, count = await db.redis.eval(LUA_ACQUIRE, 1, key, limit, ttl)
    except Exception:
        return await _db_fallback_check(user_id)
    if not allowed:
        raise HTTPException(
            status_code=429,
            detail=f"Daily limit of {limit} applications reached",
            headers={"Retry-After": str(ttl)},
        )
    return count


async def release_application_slot(user_id: str) -> None:
    key, _ = _today_key(user_id)
    try:
        await db.redis.eval(LUA_RELEASE, 1, key)
    except Exception:
        pass


async def remaining_today(user_id: str) -> int:
    key, _ = _today_key(user_id)
    try:
        used = int(await db.redis.get(key) or 0)
    except Exception:
        used = await db.pool.fetchval(
            "SELECT count(*) FROM applications WHERE user_id=$1 "
            "AND applied_at >= date_trunc('day', now() AT TIME ZONE 'utc')", user_id)
    return max(0, settings.daily_application_limit - used)


async def _db_fallback_check(user_id: str) -> int:
    """Redis down: count today's rows under a per-user advisory lock (held for this txn only)."""
    async with db.pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute("SELECT pg_advisory_xact_lock(hashtext($1))", user_id)
            n = await conn.fetchval(
                "SELECT count(*) FROM applications WHERE user_id=$1 "
                "AND applied_at >= date_trunc('day', now() AT TIME ZONE 'utc')", user_id)
            if n >= settings.daily_application_limit:
                raise HTTPException(429, "Daily application limit reached")
            return n + 1
