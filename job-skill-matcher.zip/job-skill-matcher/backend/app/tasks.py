"""Celery workers: async resume parsing and score computation."""
import numpy as np
import psycopg
import redis
from celery import Celery
from pgvector.psycopg import register_vector
from . import parsing, storage, matching
from .config import settings

celery = Celery("matcher", broker=settings.redis_url, backend=settings.redis_url)
celery.conf.update(
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_routes={"app.tasks.parse_resume": {"queue": "parse"},
                 "app.tasks.score_resume": {"queue": "score"},
                 "app.tasks.score_job": {"queue": "score"}},
    task_default_retry_delay=15,
)
_redis = redis.from_url(settings.redis_url, decode_responses=True)


def _conn():
    c = psycopg.connect(settings.database_url)
    register_vector(c)
    return c


@celery.task(bind=True, max_retries=3, name="app.tasks.parse_resume")
def parse_resume(self, resume_id: str):
    conn = _conn()
    try:
        with conn.cursor() as cur:
            cur.execute("UPDATE resumes SET status='parsing' WHERE id=%s "
                        "RETURNING storage_key, mime_type, user_id", (resume_id,))
            key, mime, user_id = cur.fetchone()
            cur.execute("SELECT id, name, aliases FROM skills")
            taxonomy = [{"id": i, "name": n, "aliases": a} for i, n, a in cur.fetchall()]

        text = parsing.extract_text(storage.read_bytes(key), mime)
        found = parsing.tag_skills(text, taxonomy)

        with conn.cursor() as cur:
            cur.execute("DELETE FROM resume_skills WHERE resume_id=%s", (resume_id,))
            cur.executemany("INSERT INTO resume_skills (resume_id, skill_id, confidence) VALUES (%s,%s,%s)",
                            [(resume_id, sid, c) for sid, c in found.items()])
            emb = None
            if found:
                cur.execute("SELECT embedding FROM skills WHERE id = ANY(%s)", (list(found),))
                emb = np.mean([r[0] for r in cur.fetchall()], axis=0)
            cur.execute("""UPDATE resumes SET raw_text=%s, search_tsv=to_tsvector('english', %s),
                           embedding=%s, status='parsed', parsed_at=now() WHERE id=%s""",
                        (text, text, emb, resume_id))
        conn.commit()
        score_resume.delay(resume_id)
    except Exception as exc:
        conn.rollback()
        with conn.cursor() as cur:
            cur.execute("UPDATE resumes SET status='failed' WHERE id=%s", (resume_id,))
        conn.commit()
        raise self.retry(exc=exc)
    finally:
        conn.close()


@celery.task(bind=True, max_retries=3, name="app.tasks.score_resume")
def score_resume(self, resume_id: str):
    conn = _conn()
    try:
        matching.score_resume(conn, resume_id)
        with conn.cursor() as cur:
            cur.execute("SELECT user_id FROM resumes WHERE id=%s", (resume_id,))
            uid = cur.fetchone()[0]
        # Invalidate cached match lists + gap views for this user/resume
        for k in _redis.scan_iter(f"matches:{uid}:*"):
            _redis.delete(k)
        for k in _redis.scan_iter(f"gap:{resume_id}:*"):
            _redis.delete(k)
    except Exception as exc:
        raise self.retry(exc=exc)
    finally:
        conn.close()


@celery.task(name="app.tasks.score_job")
def score_job(job_id: str, batch: int = 500):
    """After a job is created/edited: rescore only resumes sharing >=1 required skill, in batches."""
    conn = _conn()
    with conn.cursor() as cur:
        cur.execute("""SELECT DISTINCT rs.resume_id FROM resume_skills rs
                       JOIN job_skills js ON js.skill_id = rs.skill_id AND js.job_id = %s
                       JOIN resumes r ON r.id = rs.resume_id AND r.is_active""", (job_id,))
        ids = [r[0] for r in cur.fetchall()]
    conn.close()
    for i in range(0, len(ids), batch):
        for rid in ids[i:i + batch]:
            score_resume.apply_async(args=[str(rid)], queue="score", priority=3)
