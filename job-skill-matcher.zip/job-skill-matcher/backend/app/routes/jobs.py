import uuid
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from .. import db
from ..auth import require_role
from ..tasks import score_job

router = APIRouter(prefix="/jobs", tags=["jobs"])


class JobIn(BaseModel):
    title: str
    company: str
    description: str
    location: str | None = None
    skills: list[dict]   # [{skill_id, required, weight}]


@router.post("", status_code=201)
async def create_job(body: JobIn, user=Depends(require_role("recruiter", "admin"))):
    jid = uuid.uuid4()
    async with db.pool.acquire() as c, c.transaction():
        await c.execute(
            """INSERT INTO jobs (id, recruiter_id, title, company, description, location, search_tsv, embedding)
               VALUES ($1,$2,$3,$4,$5,$6, to_tsvector('english', $3||' '||$5),
                       (SELECT avg(embedding) FROM skills WHERE id = ANY($7)))""",
            jid, uuid.UUID(user.id), body.title, body.company, body.description, body.location,
            [s["skill_id"] for s in body.skills])
        await c.executemany(
            "INSERT INTO job_skills (job_id, skill_id, required, weight) VALUES ($1,$2,$3,$4)",
            [(jid, s["skill_id"], s.get("required", True), s.get("weight", 1.0)) for s in body.skills])
    score_job.delay(str(jid))       # async rescoring, never in the request path
    return {"id": str(jid)}
