import uuid
from fastapi import APIRouter, Depends, Query
from .. import db
from ..auth import require_role

router = APIRouter(prefix="/recruiter", tags=["recruiter"])


@router.get("/candidates")
async def candidates(
    q: str | None = None,
    skills: list[int] = Query(default=[]),          # skill ids; ALL must be present
    min_exp: float | None = None,
    location: str | None = None,
    job_id: str | None = None,                      # rank by match for this job
    min_score: float = 0,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, le=50),
    user=Depends(require_role("recruiter", "admin")),
):
    args: list = []
    where = ["r.is_active", "r.status='parsed'"]

    def add(val):
        args.append(val)
        return f"${len(args)}"

    if q:
        where.append(f"r.search_tsv @@ websearch_to_tsquery('english', {add(q)})")
    if skills:
        where.append(f"""(SELECT count(*) FROM resume_skills rs WHERE rs.resume_id=r.id
                          AND rs.skill_id = ANY({add(skills)})) = {len(skills)}""")
    if min_exp is not None:
        where.append(f"u.years_experience >= {add(min_exp)}")
    if location:
        where.append(f"u.location ILIKE {add('%' + location + '%')}")

    join_score, score_sel, order = "", "NULL::numeric AS score", "r.parsed_at DESC"
    if job_id:
        join_score = f"LEFT JOIN match_scores m ON m.resume_id=r.id AND m.job_id={add(uuid.UUID(job_id))}"
        score_sel, order = "m.score AS score", "m.score DESC NULLS LAST"
        if min_score:
            where.append(f"m.score >= {add(min_score)}")

    sql = f"""
      SELECT r.id AS resume_id, u.full_name, u.location, u.years_experience, {score_sel},
             (SELECT array_agg(s.name ORDER BY rs.confidence DESC) FROM
                (SELECT * FROM resume_skills WHERE resume_id=r.id LIMIT 8) rs
                JOIN skills s ON s.id=rs.skill_id) AS top_skills,
             count(*) OVER() AS total
      FROM resumes r JOIN users u ON u.id=r.user_id {join_score}
      WHERE {' AND '.join(where)}
      ORDER BY {order} LIMIT {page_size} OFFSET {(page - 1) * page_size}"""
    rows = await db.pool.fetch(sql, *args)
    return {"total": rows[0]["total"] if rows else 0, "page": page,
            "items": [{**{k: v for k, v in dict(r).items() if k != "total"},
                       "resume_id": str(r["resume_id"]),
                       "score": float(r["score"]) if r["score"] is not None else None} for r in rows]}
