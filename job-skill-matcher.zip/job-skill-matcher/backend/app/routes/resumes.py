import uuid
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from .. import db, storage
from ..auth import CurrentUser, get_current_user
from ..config import settings
from ..tasks import parse_resume

router = APIRouter(prefix="/resumes", tags=["resumes"])


class UploadRequest(BaseModel):
    filename: str
    mime_type: str
    size: int


@router.post("/upload-url")
async def upload_url(body: UploadRequest, user: CurrentUser = Depends(get_current_user)):
    if body.mime_type not in storage.ALLOWED:
        raise HTTPException(415, "Only PDF or DOCX allowed")
    if not (0 < body.size <= settings.max_resume_bytes):
        raise HTTPException(413, "File too large (max 5 MB)")
    rid = str(uuid.uuid4())
    key = storage.new_key(user.id, rid, body.mime_type)
    await db.pool.execute(
        "INSERT INTO resumes (id, user_id, storage_key, original_name, mime_type, status) "
        "VALUES ($1,$2,$3,$4,$5,'pending')", uuid.UUID(rid), uuid.UUID(user.id), key, body.filename, body.mime_type)
    return {"resume_id": rid, "upload": storage.presign_upload(key, body.mime_type)}


@router.post("/{resume_id}/complete", status_code=202)
async def complete(resume_id: str, user: CurrentUser = Depends(get_current_user)):
    row = await db.pool.fetchrow("SELECT storage_key FROM resumes WHERE id=$1 AND user_id=$2",
                                 uuid.UUID(resume_id), uuid.UUID(user.id))
    if not row:
        raise HTTPException(404)
    meta = storage.head(row["storage_key"])
    if not meta or meta["ContentLength"] > settings.max_resume_bytes:
        raise HTTPException(400, "Upload missing or too large")
    async with db.pool.acquire() as c, c.transaction():
        await c.execute("UPDATE resumes SET is_active=false WHERE user_id=$1 AND is_active", uuid.UUID(user.id))
        await c.execute("UPDATE resumes SET status='uploaded', is_active=true WHERE id=$1", uuid.UUID(resume_id))
    parse_resume.delay(resume_id)
    return {"status": "queued"}


@router.get("/{resume_id}")
async def get_resume(resume_id: str, user: CurrentUser = Depends(get_current_user)):
    r = await db.pool.fetchrow(
        "SELECT id, status, original_name, parsed_at FROM resumes WHERE id=$1 AND user_id=$2",
        uuid.UUID(resume_id), uuid.UUID(user.id))
    if not r:
        raise HTTPException(404)
    skills = await db.pool.fetch(
        "SELECT s.id, s.name FROM resume_skills rs JOIN skills s ON s.id=rs.skill_id WHERE rs.resume_id=$1",
        uuid.UUID(resume_id))
    return {**dict(r), "skills": [dict(s) for s in skills]}


@router.get("/{resume_id}/download-url")
async def download_url(resume_id: str, user: CurrentUser = Depends(get_current_user)):
    """Owner, or a recruiter whose job received an application from this resume's owner."""
    r = await db.pool.fetchrow("SELECT storage_key, user_id, original_name FROM resumes WHERE id=$1",
                               uuid.UUID(resume_id))
    if not r:
        raise HTTPException(404)
    allowed = str(r["user_id"]) == user.id
    if not allowed and user.role == "recruiter":
        allowed = bool(await db.pool.fetchval(
            """SELECT 1 FROM applications a JOIN jobs j ON j.id=a.job_id
               WHERE a.resume_id=$1 AND j.recruiter_id=$2 LIMIT 1""",
            uuid.UUID(resume_id), uuid.UUID(user.id)))
    if not allowed:
        raise HTTPException(403)
    return {"url": storage.presign_download(r["storage_key"], r["original_name"] or "resume"),
            "expires_in": settings.download_url_ttl}
