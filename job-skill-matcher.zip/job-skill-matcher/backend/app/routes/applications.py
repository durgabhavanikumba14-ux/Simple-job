import uuid
import asyncpg
from fastapi import APIRouter, Depends, HTTPException
from .. import db
from ..auth import CurrentUser, get_current_user
from ..config import settings
from ..rate_limit import acquire_application_slot, release_application_slot, remaining_today

router = APIRouter(prefix="/applications", tags=["applications"])


@router.post("/{job_id}", status_code=201)
async def apply(job_id: str, user: CurrentUser = Depends(get_current_user)):
    # 1) Reserve a daily slot atomically (429 if the 11th attempt)
    await acquire_application_slot(user.id)
    try:
        resume = await db.pool.fetchrow(
            "SELECT id FROM resumes WHERE user_id=$1 AND is_active AND status='parsed'", uuid.UUID(user.id))
        if not resume:
            raise HTTPException(400, "Upload a resume and wait for parsing to finish")
        job = await db.pool.fetchval("SELECT 1 FROM jobs WHERE id=$1 AND status='open'", uuid.UUID(job_id))
        if not job:
            raise HTTPException(404, "Job not found or closed")
        # 2) DB is source of truth; UNIQUE (user_id, job_id) blocks duplicates
        app_id = await db.pool.fetchval(
            """INSERT INTO applications (user_id, job_id, resume_id, score_at_apply)
               VALUES ($1,$2,$3,(SELECT score FROM match_scores WHERE resume_id=$3 AND job_id=$2))
               RETURNING id""", uuid.UUID(user.id), uuid.UUID(job_id), resume["id"])
    except asyncpg.UniqueViolationError:
        await release_application_slot(user.id)
        raise HTTPException(409, "Already applied to this job")
    except Exception:
        await release_application_slot(user.id)     # failures never burn quota
        raise
    return {"application_id": str(app_id),
            "remaining_today": await remaining_today(user.id)}


@router.get("/quota")
async def quota(user: CurrentUser = Depends(get_current_user)):
    left = await remaining_today(user.id)
    return {"limit": settings.daily_application_limit, "remaining": left,
            "used": settings.daily_application_limit - left}
