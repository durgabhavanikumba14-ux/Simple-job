import json
import random
import uuid
from fastapi import APIRouter, Depends, HTTPException, Query
from .. import db
from ..auth import CurrentUser, get_current_user

router = APIRouter(prefix="/matches", tags=["matches"])


@router.get("")
async def my_matches(limit: int = Query(20, le=50), min_score: float = 0,
                     user: CurrentUser = Depends(get_current_user)):
    key = f"matches:{user.id}:{limit}:{min_score}"
    if hit := await db.redis.get(key):
        return json.loads(hit)
    rows = await db.pool.fetch(
        """SELECT m.job_id, m.score, j.title, j.company, j.location, jsonb_array_length(m.missing) AS missing_count
           FROM match_scores m
           JOIN resumes r ON r.id = m.resume_id AND r.user_id=$1 AND r.is_active
           JOIN jobs j ON j.id = m.job_id AND j.status='open'
           WHERE m.score >= $2 ORDER BY m.score DESC LIMIT $3""",
        uuid.UUID(user.id), min_score, limit)
    out = [{**dict(r), "job_id": str(r["job_id"]), "score": float(r["score"])} for r in rows]
    await db.redis.set(key, json.dumps(out), ex=600 + random.randint(0, 60))   # jittered TTL
    return out


@router.get("/{job_id}/gap")
async def skill_gap(job_id: str, user: CurrentUser = Depends(get_current_user)):
    row = await db.pool.fetchrow(
        """SELECT m.resume_id, m.score, m.matched, m.missing FROM match_scores m
           JOIN resumes r ON r.id=m.resume_id AND r.user_id=$1 AND r.is_active
           WHERE m.job_id=$2""", uuid.UUID(user.id), uuid.UUID(job_id))
    if not row:
        raise HTTPException(404, "No score yet; resume may still be processing")
    key = f"gap:{row['resume_id']}:{job_id}"
    if hit := await db.redis.get(key):
        return json.loads(hit)
    missing = json.loads(row["missing"])
    ids = [m["skill_id"] for m in missing]
    courses = await db.pool.fetch(
        """SELECT sc.skill_id, c.title, c.provider, c.url, c.duration_hours, c.is_free
           FROM skill_courses sc JOIN courses c ON c.id=sc.course_id
           WHERE sc.skill_id = ANY($1) ORDER BY sc.rank""", ids)
    by_skill: dict[int, list] = {}
    for c in courses:
        by_skill.setdefault(c["skill_id"], []).append(
            {k: c[k] for k in ("title", "provider", "url", "duration_hours", "is_free")})
    for m in missing:
        m["courses"] = by_skill.get(m["skill_id"], [])[:3]
    out = {"job_id": job_id, "score": float(row["score"]),
           "matched": json.loads(row["matched"]), "missing": missing}
    await db.redis.set(key, json.dumps(out), ex=3600 + random.randint(0, 300))
    return out
