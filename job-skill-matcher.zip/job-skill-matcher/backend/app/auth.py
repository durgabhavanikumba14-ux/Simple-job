"""JWT auth stub. Replace with real login/refresh endpoints."""
from dataclasses import dataclass
from fastapi import Depends, HTTPException, Header
from jose import jwt, JWTError
from .config import settings


@dataclass
class CurrentUser:
    id: str
    role: str


async def get_current_user(authorization: str = Header(...)) -> CurrentUser:
    try:
        token = authorization.removeprefix("Bearer ")
        claims = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
        return CurrentUser(id=claims["sub"], role=claims.get("role", "applicant"))
    except (JWTError, KeyError):
        raise HTTPException(401, "Invalid token")


def require_role(*roles: str):
    async def dep(user: CurrentUser = Depends(get_current_user)):
        if user.role not in roles:
            raise HTTPException(403, "Forbidden")
        return user
    return dep
