from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "postgresql://matcher:matcher@localhost:5432/matcher"
    redis_url: str = "redis://localhost:6379/0"
    s3_bucket: str = "resumes-private"
    s3_region: str = "us-east-1"
    s3_endpoint_url: str | None = None          # MinIO locally, None on AWS
    jwt_secret: str = "change-me"
    daily_application_limit: int = 10
    max_resume_bytes: int = 5 * 1024 * 1024
    upload_url_ttl: int = 300                   # 5 min
    download_url_ttl: int = 60                  # 1 min
    semantic_threshold: float = 0.80
    ann_candidates: int = 200


settings = Settings()
