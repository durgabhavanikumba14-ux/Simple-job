"""Resume text extraction + skill tagging."""
import io
import re
from functools import lru_cache
from sentence_transformers import SentenceTransformer


@lru_cache(maxsize=1)
def model() -> SentenceTransformer:
    return SentenceTransformer("all-MiniLM-L6-v2")        # 384-d


def extract_text(data: bytes, mime: str) -> str:
    if mime == "application/pdf":
        from pdfminer.high_level import extract_text as pdf_text
        return pdf_text(io.BytesIO(data))
    from docx import Document
    doc = Document(io.BytesIO(data))
    parts = [p.text for p in doc.paragraphs]
    for t in doc.tables:
        for row in t.rows:
            parts.extend(c.text for c in row.cells)
    return "\n".join(parts)


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower())


def tag_skills(text: str, taxonomy: list[dict]) -> dict[int, float]:
    """
    taxonomy: [{id, name, aliases}]
    Pass 1: word-boundary match of canonical names/aliases (confidence 1.0).
    (Pass 2 - semantic: embed noun phrases and map to nearest skill when cos>=0.85. Add if recall is low.)
    """
    t = " " + normalize(text) + " "
    found: dict[int, float] = {}
    for s in taxonomy:
        for term in [s["name"], *s["aliases"]]:
            if re.search(rf"(?<![a-z0-9+#.]){re.escape(term.lower())}(?![a-z0-9+#])", t):
                found[s["id"]] = 1.0
                break
    return found
