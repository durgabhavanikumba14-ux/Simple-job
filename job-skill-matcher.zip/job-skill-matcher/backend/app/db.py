import asyncpg
import redis.asyncio as aioredis
from pgvector.asyncpg import register_vector
from .config import settings

pool: asyncpg.Pool | None = None
redis: aioredis.Redis | None = None


async def _init(conn):
    await register_vector(conn)


async def startup():
    global pool, redis
    pool = await asyncpg.create_pool(settings.database_url, min_size=5, max_size=30, init=_init)
    redis = aioredis.from_url(settings.redis_url, decode_responses=True)


async def shutdown():
    await pool.close()
    await redis.close()
