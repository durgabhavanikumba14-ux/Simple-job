"""Secure S3/GCS access: private bucket + short-lived presigned URLs."""
import uuid
import boto3
from botocore.config import Config
from .config import settings

ALLOWED = {
    "application/pdf": "pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
}

_s3 = boto3.client(
    "s3",
    region_name=settings.s3_region,
    endpoint_url=settings.s3_endpoint_url,
    config=Config(signature_version="s3v4"),
)


def new_key(user_id: str, resume_id: str, mime: str) -> str:
    # Never use the user-supplied filename in the key
    return f"resumes/{user_id}/{resume_id}/{uuid.uuid4().hex}.{ALLOWED[mime]}"


def presign_upload(key: str, mime: str) -> dict:
    """POST policy lets S3 itself enforce the size cap and content type."""
    return _s3.generate_presigned_post(
        settings.s3_bucket, key,
        Fields={"Content-Type": mime, "x-amz-server-side-encryption": "AES256"},
        Conditions=[
            {"Content-Type": mime},
            {"x-amz-server-side-encryption": "AES256"},
            ["content-length-range", 1, settings.max_resume_bytes],
        ],
        ExpiresIn=settings.upload_url_ttl,
    )


def presign_download(key: str, filename: str = "resume") -> str:
    return _s3.generate_presigned_url(
        "get_object",
        Params={"Bucket": settings.s3_bucket, "Key": key,
                "ResponseContentDisposition": f'attachment; filename="{filename}"'},
        ExpiresIn=settings.download_url_ttl,
    )


def head(key: str) -> dict | None:
    try:
        return _s3.head_object(Bucket=settings.s3_bucket, Key=key)
    except Exception:
        return None


def read_bytes(key: str) -> bytes:
    return _s3.get_object(Bucket=settings.s3_bucket, Key=key)["Body"].read()
