"""Scoring (sync, used by Celery workers via psycopg)."""
import json
from .config import settings

TOP_K_SQL = """
WITH cand AS (
  SELECT j.id FROM jobs j, (SELECT embedding FROM resumes WHERE id = %(rid)s) r
  WHERE j.status = 'open'
  ORDER BY j.embedding <=> r.embedding
  LIMIT %(k)s
)
SELECT js.job_id, js.skill_id, s.name, js.required,
       (CASE WHEN js.required THEN 2.0 ELSE 1.0 END) * js.weight AS w,
       COALESCE(best.sim, 0) AS sim
FROM job_skills js
JOIN cand c  ON c.id = js.job_id
JOIN skills s ON s.id = js.skill_id
LEFT JOIN LATERAL (
  SELECT MAX(CASE WHEN rs.skill_id = js.skill_id THEN 1.0
                  ELSE 1 - (s.embedding <=> s2.embedding) END) AS sim
  FROM resume_skills rs JOIN skills s2 ON s2.id = rs.skill_id
  WHERE rs.resume_id = %(rid)s
) best ON true
"""


def score_resume(conn, resume_id: str) -> int:
    """Compute and upsert top-K match scores for one resume. Returns rows written."""
    thr = settings.semantic_threshold
    with conn.cursor() as cur:
        cur.execute(TOP_K_SQL, {"rid": resume_id, "k": settings.ann_candidates})
        rows = cur.fetchall()

    jobs: dict[str, dict] = {}
    for job_id, skill_id, name, required, w, sim in rows:
        j = jobs.setdefault(job_id, {"num": 0.0, "den": 0.0, "matched": [], "missing": []})
        j["den"] += w
        if sim >= thr:
            j["num"] += w * sim
            j["matched"].append({"skill_id": skill_id, "name": name, "sim": round(float(sim), 3)})
        else:
            j["missing"].append({"skill_id": skill_id, "name": name, "required": required})

    with conn.cursor() as cur:
        for job_id, j in jobs.items():
            score = round(100 * j["num"] / j["den"], 2) if j["den"] else 0
            cur.execute(
                """INSERT INTO match_scores (resume_id, job_id, score, matched, missing, computed_at)
                   VALUES (%s,%s,%s,%s,%s, now())
                   ON CONFLICT (resume_id, job_id) DO UPDATE
                   SET score=EXCLUDED.score, matched=EXCLUDED.matched,
                       missing=EXCLUDED.missing, computed_at=now()""",
                (resume_id, job_id, score, json.dumps(j["matched"]), json.dumps(j["missing"])),
            )
    conn.commit()
    return len(jobs)
