from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from . import db
from .routes import resumes, matches, applications, recruiter, jobs


@asynccontextmanager
async def lifespan(app: FastAPI):
    await db.startup()
    yield
    await db.shutdown()


app = FastAPI(title="Job Skill Matcher", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"],
                   allow_methods=["*"], allow_headers=["*"])
for r in (resumes, matches, applications, recruiter, jobs):
    app.include_router(r.router)


@app.get("/health")
async def health():
    return {"ok": True}
